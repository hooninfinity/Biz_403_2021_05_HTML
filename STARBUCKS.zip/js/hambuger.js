const menuTrigger = document.querySelector(".menu-trigger");

menuTrigger.addEventListener("click", (event) => {
  event.currentTarget.classList.toggle("active-1");
});
